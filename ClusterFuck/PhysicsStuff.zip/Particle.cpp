#include "Particle.h"

Particle::Particle() : position(Vector3(0.0f))
, velocity(Vector3(0.0f))
, acceleration(Vector3(0.0f))
, damping(1.0f)
, mass(1.0f)
{

}

Particle::~Particle() {

}


//Calculate particle position and velocity
void Particle::calculate(float dt) {
    /*velocity.scalevector(acceleration, dt);
    velocity = velocity * damping;
    position.scalevector(velocity, dt);*/
    
    velocity = velocity + acceleration * dt;
    velocity = velocity * damping;
    position = position + velocity * dt;
}

//void Particle::print0(float dt) {
//    std::cout << "position = " << position.y << " + " << velocity.y << " * " << dt << "\n";
//    velocity = velocity + acceleration * dt;
//    std::cout << "position = " << position.y << " + " << velocity.y << " * " << dt << "\n";
//    position = position + velocity * dt;
//}

void Particle::print1() {
    std::cout << "\nPosition: " << position.x << ", " << position.y << ", " << position.z << std::endl;
    std::cout << "\nVelocity: " << velocity.x << ", " << velocity.y << ", " << velocity.z << std::endl;
}