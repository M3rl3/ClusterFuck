#pragma once

#include "Particle.h"

#include <vector>

class ParticleAccelerator {

	std::vector<Particle> particles;

public:
	ParticleAccelerator();
	~ParticleAccelerator();

	Particle initparticle(const Vector3);
	void calculate_pa(float time);

	//Particle part;
};